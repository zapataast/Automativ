#!/bin/sh

echo "Shell Script CUPS Driver Removing Started !!!"
cd install;chmod +x remove
exec ./remove
echo "Shell Script CUPS Driver Removing Ended !!!"

